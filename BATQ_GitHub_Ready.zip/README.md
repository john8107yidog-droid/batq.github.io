# B&T Questions - Wholesome Connection App

A beautiful PWA for couples to explore meaningful questions together.

## Deployment to GitHub Pages

To deploy this application to GitHub Pages, follow these steps:

1.  **Create a new GitHub Repository**: If you haven't already, create a new public GitHub repository for this project.

2.  **Upload the Code**: Upload all the files from this project to the root of your new GitHub repository.

3.  **Enable GitHub Pages**: 
    *   Go to your repository on GitHub.
    *   Click on the "Settings" tab.
    *   In the left sidebar, click on "Pages" under the "Code and automation" section.
    *   Under "Build and deployment", select "Deploy from a branch".
    *   For "Branch", select `main` (or your primary branch) and choose `/ (root)` for the folder.
    *   Click "Save".

4.  **Access Your Site**: GitHub Pages will build and deploy your site. This may take a few minutes. Once deployed, your application will be accessible at `https://<YOUR_USERNAME>.github.io/<YOUR_REPOSITORY_NAME>/`.

**Note**: This project includes a `.nojekyll` file to ensure GitHub Pages serves the site as a static website without processing it through Jekyll.
